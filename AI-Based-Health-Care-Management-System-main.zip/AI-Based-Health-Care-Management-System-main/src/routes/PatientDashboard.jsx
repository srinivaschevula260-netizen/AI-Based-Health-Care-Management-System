import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar, 
  FileText, 
  Heart, 
  MessageCircle, 
  LogOut, 
  User,
  Clock,
  Stethoscope,
  Activity,
  Brain
} from 'lucide-react';
import AppointmentBooking from '../components/patient/AppointmentBooking';
import MedicalHistory from '../components/patient/MedicalHistory';
import LifestylePlans from '../components/patient/LifestylePlans';
import AIAssistant from '../components/patient/AIAssistant';
import { getAppointments, getPatientMedicalHistory } from '../utils/database';

const PatientDashboard = () => {
  const { currentUser, userRole, logout } = useAuth();
  const [upcomingAppointments, setUpcomingAppointments] = useState([]);
  const [medicalHistory, setMedicalHistory] = useState(null);
  const [lifestylePlans, setLifestylePlans] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (currentUser) {
        try {
          // Fetch appointments
          const appointments = await getAppointments(currentUser.uid, 'patient');
          const upcoming = appointments
            .filter(apt => apt.status === 'scheduled' && new Date(apt.date) >= new Date())
            .sort((a, b) => new Date(a.date) - new Date(b.date))
            .slice(0, 3);
          setUpcomingAppointments(upcoming);

          // Fetch medical history
          const medicalData = await getPatientMedicalHistory(currentUser.uid);
          setMedicalHistory(medicalData);

          // Fetch lifestyle plans (from localStorage or database)
          const storedPlans = localStorage.getItem(`lifestylePlans_${currentUser.uid}`);
          if (storedPlans) {
            setLifestylePlans(JSON.parse(storedPlans));
          }

        } catch (error) {
          console.error('Error fetching dashboard data:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchDashboardData();
  }, [currentUser]);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  // Calculate medical records stats
  const getMedicalRecordsCount = () => {
    if (!medicalHistory) return 0;
    const conditions = medicalHistory.conditions?.length || 0;
    const medications = medicalHistory.medications?.length || 0;
    const allergies = medicalHistory.allergies?.length || 0;
    return conditions + medications + allergies;
  };

  // Calculate health plans stats
  const getHealthPlansCount = () => {
    if (!lifestylePlans) return 0;
    let count = 0;
    if (lifestylePlans.dietPlan) count++;
    if (lifestylePlans.exercisePlan) count++;
    if (lifestylePlans.sleepPlan) count++;
    if (lifestylePlans.stressPlan) count++;
    return count;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center min-w-0 flex-1">
              <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-purple-600 mr-2 sm:mr-3 flex-shrink-0" />
              <h1 className="text-lg sm:text-xl font-semibold text-gray-900 truncate">
                Patient Portal
              </h1>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 flex-shrink-0">
              <div className="hidden sm:flex items-center space-x-2">
                <User className="h-5 w-5 text-purple-600" />
                <span className="text-sm font-medium text-gray-700 truncate max-w-[150px] lg:max-w-none">
                  {currentUser?.email}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout} className="text-xs sm:text-sm">
                <LogOut className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Welcome Section */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Welcome to Your Health Portal
            </h2>
            <p className="text-gray-600">
              Manage your appointments, medical records, and health insights all in one place.
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Upcoming Appointments</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{upcomingAppointments.length}</div>
                <p className="text-xs text-muted-foreground">
                  Next appointment scheduled
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Medical Records</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{getMedicalRecordsCount()}</div>
                <p className="text-xs text-muted-foreground">
                  {getMedicalRecordsCount() === 0 ? 'No records yet' : 
                   getMedicalRecordsCount() === 1 ? '1 record' : 
                   `${getMedicalRecordsCount()} records`}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Health Plans</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{getHealthPlansCount()}</div>
                <p className="text-xs text-muted-foreground">
                  {getHealthPlansCount() === 0 ? 'No plans created' : 
                   getHealthPlansCount() === 1 ? '1 active plan' : 
                   `${getHealthPlansCount()} active plans`}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">AI Assistant</CardTitle>
                <Brain className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24/7</div>
                <p className="text-xs text-muted-foreground">
                  Health insights available
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Appointments */}
          {upcomingAppointments.length > 0 && (
            <Card className="mb-6 sm:mb-8">
              <CardHeader>
                <CardTitle className="flex items-center text-base sm:text-lg">
                  <Clock className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                  Upcoming Appointments
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Your next scheduled appointments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 sm:space-y-4">
                  {upcomingAppointments.map((appointment) => (
                    <div key={appointment.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 border rounded-lg gap-3 sm:gap-0">
                      <div className="flex items-center space-x-3 sm:space-x-4">
                        <div className="flex-shrink-0">
                          <Stethoscope className="h-6 w-6 sm:h-8 sm:w-8 text-green-600" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm sm:text-base truncate">Dr. {appointment.doctorName || 'Doctor'}</p>
                          <p className="text-xs sm:text-sm text-gray-600 truncate">{appointment.specialization || 'General Practice'}</p>
                        </div>
                      </div>
                      <div className="text-left sm:text-right">
                        <p className="font-medium text-sm sm:text-base">{formatDate(appointment.date)}</p>
                        <p className="text-xs sm:text-sm text-gray-600">{formatTime(appointment.time)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Main Content Tabs */}
          <Card>
            <CardContent className="p-4 sm:p-6">
              <Tabs defaultValue="appointments" className="w-full">
                <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
                  <TabsTrigger value="appointments" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden xs:inline">Appointments</span>
                    <span className="xs:hidden">Appts</span>
                  </TabsTrigger>
                  <TabsTrigger value="medical" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
                    <FileText className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden xs:inline">Medical</span>
                    <span className="xs:hidden">Medical</span>
                  </TabsTrigger>
                  <TabsTrigger value="lifestyle" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
                    <Activity className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden xs:inline">Health Plans</span>
                    <span className="xs:hidden">Plans</span>
                  </TabsTrigger>
                  <TabsTrigger value="ai" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
                    <MessageCircle className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden xs:inline">AI Assistant</span>
                    <span className="xs:hidden">AI</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="appointments" className="mt-4 sm:mt-6">
                  <AppointmentBooking />
                </TabsContent>

                <TabsContent value="medical" className="mt-4 sm:mt-6">
                  <MedicalHistory onDataUpdate={() => {
                    // Refresh medical history data when updated
                    const refreshData = async () => {
                      if (currentUser) {
                        const medicalData = await getPatientMedicalHistory(currentUser.uid);
                        setMedicalHistory(medicalData);
                      }
                    };
                    refreshData();
                  }} />
                </TabsContent>

                <TabsContent value="lifestyle" className="mt-4 sm:mt-6">
                  <LifestylePlans onDataUpdate={() => {
                    // Refresh lifestyle plans data when updated
                    if (currentUser) {
                      const storedPlans = localStorage.getItem(`lifestylePlans_${currentUser.uid}`);
                      if (storedPlans) {
                        setLifestylePlans(JSON.parse(storedPlans));
                      }
                    }
                  }} />
                </TabsContent>

                <TabsContent value="ai" className="mt-4 sm:mt-6">
                  <AIAssistant />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default PatientDashboard;
