import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Activity, 
  Apple, 
  Plus, 
  Edit, 
  Trash2, 
  AlertCircle, 
  CheckCircle,
  Target,
  Clock,
  Flame,
  Heart,
  TrendingUp,
  Save,
  Loader2,
  Droplet,
  Zap,
  BarChart3,
  Award
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { getMedicalHistory, updateMedicalHistory } from '../../utils/database';

const LifestylePlans = ({ onDataUpdate }) => {
  const { currentUser } = useAuth();
  const [lifestyleData, setLifestyleData] = useState({
    dietPlan: {
      goals: '',
      restrictions: [],
      meals: [],
      waterIntake: 0,
      supplements: []
    },
    exercisePlan: {
      goals: '',
      weeklyTarget: 0,
      activities: [],
      progress: []
    },
    healthMetrics: {
      weight: [],
      bloodPressure: [],
      heartRate: [],
      sleepHours: [],
      bloodSugar: [],
      temperature: []
    }
  });
  const [loading, setLoading] = useState(false);
  const [savingSection, setSavingSection] = useState(null); // Track which section is being saved
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [activeTab, setActiveTab] = useState('diet');
  
  // Local state for unsaved changes
  const [localDietData, setLocalDietData] = useState(null);
  const [localExerciseData, setLocalExerciseData] = useState(null);
  const [localMetricsData, setLocalMetricsData] = useState(null);

  // Form states
  const [newMeal, setNewMeal] = useState({ name: '', time: '', calories: '', notes: '' });
  const [newRestriction, setNewRestriction] = useState({ type: '', description: '' });
  const [newSupplement, setNewSupplement] = useState({ name: '', dosage: '', frequency: '' });
  const [newActivity, setNewActivity] = useState({ name: '', duration: '', intensity: '', calories: '' });
  const [newMetric, setNewMetric] = useState({ 
    type: '', 
    value: '', 
    date: new Date().toISOString().split('T')[0], 
    notes: '' 
  });

  useEffect(() => {
    fetchLifestyleData();
  }, [currentUser]);

  const fetchLifestyleData = async () => {
    if (currentUser) {
      try {
        const history = await getMedicalHistory(currentUser.uid);
        if (history && history.lifestylePlans) {
          setLifestyleData(history.lifestylePlans);
          // Reset local states when data is loaded
          setLocalDietData(null);
          setLocalExerciseData(null);
          setLocalMetricsData(null);
        }
      } catch (error) {
        console.error('Error fetching lifestyle data:', error);
        setError('Failed to load lifestyle data');
      }
    }
  };

  const saveLifestyleData = async (updatedData) => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const history = await getMedicalHistory(currentUser.uid) || {};
      await updateMedicalHistory(currentUser.uid, {
        ...history,
        lifestylePlans: updatedData
      });
      setLifestyleData(updatedData);
      setSuccess('Lifestyle plan updated successfully!');
      
      // Reset local states after successful save
      setLocalDietData(null);
      setLocalExerciseData(null);
      setLocalMetricsData(null);
      
      // Notify parent component of data update
      if (onDataUpdate) {
        onDataUpdate();
      }
    } catch (error) {
      console.error('Error updating lifestyle data:', error);
      setError('Failed to update lifestyle plan');
    } finally {
      setLoading(false);
      setSavingSection(null);
    }
  };

  // Save specific section
  const saveSection = async (section) => {
    setSavingSection(section);
    setError('');
    setSuccess('');

    let updatedData = { ...lifestyleData };

    if (section === 'diet' && localDietData) {
      updatedData.dietPlan = { 
        ...lifestyleData.dietPlan, 
        ...localDietData,
        meals: localDietData.meals || lifestyleData.dietPlan.meals || [],
        restrictions: localDietData.restrictions || lifestyleData.dietPlan.restrictions || [],
        supplements: localDietData.supplements || lifestyleData.dietPlan.supplements || []
      };
      await saveLifestyleData(updatedData);
    } else if (section === 'exercise' && localExerciseData) {
      updatedData.exercisePlan = { 
        ...lifestyleData.exercisePlan, 
        ...localExerciseData,
        activities: localExerciseData.activities || lifestyleData.exercisePlan.activities || []
      };
      await saveLifestyleData(updatedData);
    } else if (section === 'metrics' && localMetricsData) {
      // Merge local metrics with existing saved metrics
      const existingMetrics = lifestyleData.healthMetrics || {};
      updatedData.healthMetrics = { 
        ...existingMetrics,
        weight: localMetricsData.weight !== undefined ? localMetricsData.weight : existingMetrics.weight || [],
        bloodPressure: localMetricsData.bloodPressure !== undefined ? localMetricsData.bloodPressure : existingMetrics.bloodPressure || [],
        heartRate: localMetricsData.heartRate !== undefined ? localMetricsData.heartRate : existingMetrics.heartRate || [],
        sleepHours: localMetricsData.sleepHours !== undefined ? localMetricsData.sleepHours : existingMetrics.sleepHours || [],
        bloodSugar: localMetricsData.bloodSugar !== undefined ? localMetricsData.bloodSugar : existingMetrics.bloodSugar || [],
        temperature: localMetricsData.temperature !== undefined ? localMetricsData.temperature : existingMetrics.temperature || []
      };
      await saveLifestyleData(updatedData);
    } else {
      setSavingSection(null);
      setError('No changes to save');
    }
  };

  const addMeal = () => {
    if (!newMeal.name) {
      setError('Please enter a meal name');
      return;
    }

    const currentMeals = localDietData?.meals || lifestyleData.dietPlan.meals || [];
    setLocalDietData({
      ...localDietData,
      meals: [...currentMeals, { ...newMeal, id: Date.now() }]
    });
    setNewMeal({ name: '', time: '', calories: '', notes: '' });
  };

  const addRestriction = () => {
    if (!newRestriction.type) {
      setError('Please enter a restriction type');
      return;
    }

    const currentRestrictions = localDietData?.restrictions || lifestyleData.dietPlan.restrictions || [];
    setLocalDietData({
      ...localDietData,
      restrictions: [...currentRestrictions, { ...newRestriction, id: Date.now() }]
    });
    setNewRestriction({ type: '', description: '' });
  };

  const addSupplement = () => {
    if (!newSupplement.name) {
      setError('Please enter a supplement name');
      return;
    }

    const currentSupplements = localDietData?.supplements || lifestyleData.dietPlan.supplements || [];
    setLocalDietData({
      ...localDietData,
      supplements: [...currentSupplements, { ...newSupplement, id: Date.now() }]
    });
    setNewSupplement({ name: '', dosage: '', frequency: '' });
  };

  const addActivity = () => {
    if (!newActivity.name) {
      setError('Please enter an activity name');
      return;
    }

    const currentActivities = localExerciseData?.activities || lifestyleData.exercisePlan.activities || [];
    setLocalExerciseData({
      ...localExerciseData,
      activities: [...currentActivities, { ...newActivity, id: Date.now() }]
    });
    setNewActivity({ name: '', duration: '', intensity: '', calories: '' });
  };

  const addHealthMetric = () => {
    if (!newMetric.type || !newMetric.value) {
      setError('Please enter metric type and value');
      return;
    }

    if (!newMetric.date) {
      setError('Please select a date');
      return;
    }

    // Get current metrics from local state or saved data
    const currentMetrics = localMetricsData?.[newMetric.type] || 
                          lifestyleData.healthMetrics?.[newMetric.type] || [];
    
    // Initialize localMetricsData if it doesn't exist
    const updatedLocalMetrics = {
      ...localMetricsData,
      ...lifestyleData.healthMetrics, // Start with saved data
      [newMetric.type]: [...currentMetrics, { 
        ...newMetric, 
        id: Date.now(),
        date: newMetric.date || new Date().toISOString().split('T')[0],
        timestamp: new Date(newMetric.date).getTime() // Add timestamp for sorting
      }]
    };
    
    setLocalMetricsData(updatedLocalMetrics);
    setNewMetric({ 
      type: '', 
      value: '', 
      date: new Date().toISOString().split('T')[0], 
      notes: '' 
    });
    setError(''); // Clear any previous errors
    setSuccess('Metric added! Remember to save your changes.');
  };

  const removeItem = (section, subsection, id) => {
    if (section === 'dietPlan') {
      const currentItems = localDietData?.[subsection] || lifestyleData.dietPlan[subsection] || [];
      setLocalDietData({
        ...localDietData,
        [subsection]: currentItems.filter(item => item.id !== id)
      });
    } else if (section === 'exercisePlan') {
      const currentItems = localExerciseData?.[subsection] || lifestyleData.exercisePlan[subsection] || [];
      setLocalExerciseData({
        ...localExerciseData,
        [subsection]: currentItems.filter(item => item.id !== id)
      });
    } else if (section === 'healthMetrics') {
      const currentItems = localMetricsData?.[subsection] || lifestyleData.healthMetrics[subsection] || [];
      setLocalMetricsData({
        ...localMetricsData,
        [subsection]: currentItems.filter(item => item.id !== id)
      });
    }
  };

  // Get items for display (from local state if exists, otherwise from saved data)
  const getItems = (section, subsection) => {
    if (section === 'dietPlan' && localDietData?.[subsection]) {
      return localDietData[subsection];
    }
    if (section === 'exercisePlan' && localExerciseData?.[subsection]) {
      return localExerciseData[subsection];
    }
    if (section === 'healthMetrics' && localMetricsData?.[subsection]) {
      return localMetricsData[subsection];
    }
    return lifestyleData[section]?.[subsection] || [];
  };

  // Prepare chart data for health metrics
  const prepareChartData = (metricType) => {
    const metrics = getItems('healthMetrics', metricType);
    if (!metrics || metrics.length === 0) return [];

    return metrics
      .filter(m => m.date && m.value)
      .sort((a, b) => {
        const dateA = new Date(a.date || a.timestamp || 0);
        const dateB = new Date(b.date || b.timestamp || 0);
        return dateA - dateB;
      })
      .map(metric => {
        // Parse value for numeric metrics
        let numericValue = parseFloat(metric.value);
        
        // Handle blood pressure (format: "120/80")
        if (metricType === 'bloodPressure' && metric.value.includes('/')) {
          const [systolic, diastolic] = metric.value.split('/').map(v => parseFloat(v.trim()));
          return {
            date: new Date(metric.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            fullDate: metric.date,
            systolic: systolic || 0,
            diastolic: diastolic || 0,
            value: metric.value,
            notes: metric.notes
          };
        }
        
        // Handle weight (might have "kg" or "lbs")
        if (metricType === 'weight') {
          numericValue = parseFloat(metric.value.replace(/[^\d.]/g, ''));
        }
        
        // Handle sleep hours
        if (metricType === 'sleepHours') {
          numericValue = parseFloat(metric.value.replace(/[^\d.]/g, ''));
        }
        
        // Handle temperature
        if (metricType === 'temperature') {
          numericValue = parseFloat(metric.value.replace(/[^\d.]/g, ''));
        }

        return {
          date: new Date(metric.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          fullDate: metric.date,
          value: numericValue || 0,
          rawValue: metric.value,
          notes: metric.notes
        };
      });
  };

  // Calculate insights from diet and exercise data
  const calculateInsights = () => {
    const meals = getItems('dietPlan', 'meals');
    const activities = getItems('exercisePlan', 'activities');
    const waterIntake = getCurrentValue('dietPlan', 'waterIntake') || lifestyleData.dietPlan.waterIntake || 0;
    const weeklyTarget = getCurrentValue('exercisePlan', 'weeklyTarget') || lifestyleData.exercisePlan.weeklyTarget || 0;

    // Diet Insights
    const totalDailyCalories = meals.reduce((sum, meal) => {
      return sum + (parseInt(meal.calories) || 0);
    }, 0);

    const averageMealsPerDay = meals.length > 0 ? meals.length : 0;
    const mealTimes = meals.map(m => m.time).filter(Boolean);
    const hasBreakfast = mealTimes.some(time => {
      const hour = parseInt(time.split(':')[0]);
      return hour >= 6 && hour < 10;
    });
    const hasLunch = mealTimes.some(time => {
      const hour = parseInt(time.split(':')[0]);
      return hour >= 11 && hour < 14;
    });
    const hasDinner = mealTimes.some(time => {
      const hour = parseInt(time.split(':')[0]);
      return hour >= 17 && hour < 21;
    });

    const dietAdherence = Math.round(
      ((hasBreakfast ? 1 : 0) + (hasLunch ? 1 : 0) + (hasDinner ? 1 : 0)) / 3 * 100
    );

    // Exercise Insights
    const totalExerciseMinutes = activities.reduce((sum, activity) => {
      return sum + (parseInt(activity.duration) || 0);
    }, 0);

    const totalExerciseHours = (totalExerciseMinutes / 60).toFixed(1);
    const totalCaloriesBurned = activities.reduce((sum, activity) => {
      return sum + (parseInt(activity.calories) || 0);
    }, 0);

    const exerciseFrequency = activities.length;
    const weeklyProgress = weeklyTarget > 0 
      ? Math.round((parseFloat(totalExerciseHours) / weeklyTarget) * 100)
      : 0;

    const intensityDistribution = {
      low: activities.filter(a => a.intensity === 'low').length,
      moderate: activities.filter(a => a.intensity === 'moderate').length,
      high: activities.filter(a => a.intensity === 'high').length,
      veryHigh: activities.filter(a => a.intensity === 'very-high').length
    };

    // Health Score (composite metric)
    const healthScore = Math.round(
      (Math.min(dietAdherence, 100) * 0.3) +
      (Math.min(weeklyProgress, 100) * 0.4) +
      (waterIntake >= 8 ? 30 : (waterIntake / 8) * 30)
    );

    return {
      diet: {
        totalDailyCalories,
        averageMealsPerDay,
        waterIntake,
        hasBreakfast,
        hasLunch,
        hasDinner,
        dietAdherence,
        supplementsCount: getItems('dietPlan', 'supplements').length,
        restrictionsCount: getItems('dietPlan', 'restrictions').length
      },
      exercise: {
        totalExerciseHours: parseFloat(totalExerciseHours),
        totalExerciseMinutes,
        totalCaloriesBurned,
        exerciseFrequency,
        weeklyTarget,
        weeklyProgress,
        intensityDistribution,
        averageDuration: activities.length > 0 
          ? Math.round(totalExerciseMinutes / activities.length)
          : 0
      },
      overall: {
        healthScore,
        recommendations: generateRecommendations(waterIntake, weeklyProgress, dietAdherence, totalDailyCalories)
      }
    };
  };

  const generateRecommendations = (waterIntake, weeklyProgress, dietAdherence, totalCalories) => {
    const recommendations = [];
    
    if (waterIntake < 8) {
      recommendations.push({
        type: 'water',
        message: `Increase water intake. Currently ${waterIntake} glasses, aim for 8-10 glasses daily.`,
        priority: 'high'
      });
    }

    if (weeklyProgress < 50) {
      recommendations.push({
        type: 'exercise',
        message: `Increase exercise frequency. You're at ${weeklyProgress}% of your weekly target.`,
        priority: 'medium'
      });
    }

    if (dietAdherence < 70) {
      recommendations.push({
        type: 'diet',
        message: `Improve meal consistency. Try to have regular breakfast, lunch, and dinner.`,
        priority: 'medium'
      });
    }

    if (totalCalories < 1200) {
      recommendations.push({
        type: 'calories',
        message: `Consider increasing calorie intake. Current daily intake may be too low.`,
        priority: 'high'
      });
    } else if (totalCalories > 3000) {
      recommendations.push({
        type: 'calories',
        message: `Monitor calorie intake. Current daily intake is quite high.`,
        priority: 'medium'
      });
    }

    if (recommendations.length === 0) {
      recommendations.push({
        type: 'success',
        message: 'Great job! You\'re maintaining a healthy lifestyle. Keep it up!',
        priority: 'low'
      });
    }

    return recommendations;
  };

  // Update local state instead of auto-saving
  const updateGoal = (section, goal) => {
    if (section === 'dietPlan') {
      setLocalDietData({ ...localDietData, goals: goal });
    } else if (section === 'exercisePlan') {
      setLocalExerciseData({ ...localExerciseData, goals: goal });
    }
  };

  const updateWaterIntake = (amount) => {
    setLocalDietData({ ...localDietData, waterIntake: amount });
  };

  const updateWeeklyTarget = (target) => {
    setLocalExerciseData({ ...localExerciseData, weeklyTarget: target });
  };

  // Get current value (from local state if exists, otherwise from saved data)
  const getCurrentValue = (section, field) => {
    if (section === 'dietPlan' && localDietData && localDietData[field] !== undefined) {
      return localDietData[field];
    }
    if (section === 'exercisePlan' && localExerciseData && localExerciseData[field] !== undefined) {
      return localExerciseData[field];
    }
    return lifestyleData[section]?.[field] || '';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold">Lifestyle & Health Plans</h3>
        <p className="text-sm text-gray-600">Manage your diet, exercise, and health tracking</p>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">{success}</AlertDescription>
        </Alert>
      )}

      {/* Lifestyle Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 h-auto">
          <TabsTrigger value="diet" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
            <Apple className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden sm:inline">Diet Plan</span>
            <span className="sm:hidden">Diet</span>
          </TabsTrigger>
          <TabsTrigger value="exercise" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
            <Activity className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden sm:inline">Exercise</span>
            <span className="sm:hidden">Exercise</span>
          </TabsTrigger>
          <TabsTrigger value="metrics" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-1.5">
            <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden sm:inline">Health Metrics</span>
            <span className="sm:hidden">Metrics</span>
          </TabsTrigger>
        </TabsList>

        {/* Diet Plan Tab */}
        <TabsContent value="diet" className="space-y-6">
          {/* Diet Goals */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Diet Goals
                  </CardTitle>
                  <CardDescription>Set your dietary objectives</CardDescription>
                </div>
                {(localDietData?.goals !== undefined || localDietData?.waterIntake !== undefined || 
                  localDietData?.meals || localDietData?.restrictions || localDietData?.supplements) && (
                  <Button 
                    onClick={() => saveSection('diet')} 
                    disabled={savingSection === 'diet'}
                    className="ml-auto"
                  >
                    {savingSection === 'diet' ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="diet-goals">Dietary Goals</Label>
                <Textarea
                  id="diet-goals"
                  value={getCurrentValue('dietPlan', 'goals')}
                  onChange={(e) => updateGoal('dietPlan', e.target.value)}
                  placeholder="e.g., Lose 10 pounds, reduce sodium intake, increase protein..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Water Intake */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Heart className="h-5 w-5 mr-2" />
                Daily Water Intake
              </CardTitle>
              <CardDescription>Track your hydration goals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="water-intake">Glasses per day</Label>
                <Input
                  id="water-intake"
                  type="number"
                  value={getCurrentValue('dietPlan', 'waterIntake') || 0}
                  onChange={(e) => updateWaterIntake(parseInt(e.target.value) || 0)}
                  placeholder="8"
                  min="0"
                  max="20"
                />
              </div>
            </CardContent>
          </Card>

          {/* Meal Planning */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Meal Planning
              </CardTitle>
              <CardDescription>Plan your daily meals</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add New Meal Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-gray-50">
                <div className="space-y-2">
                  <Label htmlFor="meal-name">Meal Name</Label>
                  <Input
                    id="meal-name"
                    value={newMeal.name}
                    onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                    placeholder="e.g., Breakfast, Lunch, Snack"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="meal-time">Time</Label>
                  <Input
                    id="meal-time"
                    type="time"
                    value={newMeal.time}
                    onChange={(e) => setNewMeal({ ...newMeal, time: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="meal-calories">Calories</Label>
                  <Input
                    id="meal-calories"
                    type="number"
                    value={newMeal.calories}
                    onChange={(e) => setNewMeal({ ...newMeal, calories: e.target.value })}
                    placeholder="e.g., 300"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="meal-notes">Notes</Label>
                  <Textarea
                    id="meal-notes"
                    value={newMeal.notes}
                    onChange={(e) => setNewMeal({ ...newMeal, notes: e.target.value })}
                    placeholder="Food items, preparation notes..."
                    rows={2}
                  />
                </div>
                <div className="md:col-span-2">
                  <Button onClick={addMeal} disabled={loading}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Meal
                  </Button>
                </div>
              </div>

              {/* Existing Meals */}
              <div className="space-y-2">
                {getItems('dietPlan', 'meals')?.map((meal) => (
                  <div key={meal?.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{meal?.name}</h4>
                      <p className="text-sm text-gray-600">
                        Time: {meal?.time} | Calories: {meal?.calories}
                      </p>
                      {meal?.notes && (
                        <p className="text-sm text-gray-500 mt-1">{meal?.notes}</p>
                      )}
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeItem('dietPlan', 'meals', meal?.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {getItems('dietPlan', 'meals')?.length === 0 && (
                  <p className="text-center text-gray-500 py-4">No meals planned yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Dietary Restrictions */}
          <Card>
            <CardHeader>
              <CardTitle>Dietary Restrictions</CardTitle>
              <CardDescription>Record any food allergies or dietary limitations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add New Restriction Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-gray-50">
                <div className="space-y-2">
                  <Label htmlFor="restriction-type">Restriction Type</Label>
                  <Select value={newRestriction.type} onValueChange={(value) => setNewRestriction({ ...newRestriction, type: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="allergy">Allergy</SelectItem>
                      <SelectItem value="intolerance">Intolerance</SelectItem>
                      <SelectItem value="preference">Dietary Preference</SelectItem>
                      <SelectItem value="medical">Medical Restriction</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="restriction-description">Description</Label>
                  <Textarea
                    id="restriction-description"
                    value={newRestriction.description}
                    onChange={(e) => setNewRestriction({ ...newRestriction, description: e.target.value })}
                    placeholder="Describe the restriction..."
                    rows={2}
                  />
                </div>
                <div className="md:col-span-2">
                  <Button onClick={addRestriction} disabled={loading}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Restriction
                  </Button>
                </div>
              </div>

              {/* Existing Restrictions */}
              <div className="space-y-2">
                {getItems('dietPlan', 'restrictions')?.map((restriction) => (
                  <div key={restriction?.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{restriction?.type}</h4>
                      <p className="text-sm text-gray-600">{restriction?.description}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeItem('dietPlan', 'restrictions', restriction?.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {getItems('dietPlan', 'restrictions')?.length === 0 && (
                  <p className="text-center text-gray-500 py-4">No restrictions recorded</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Supplements */}
          <Card>
            <CardHeader>
              <CardTitle>Supplements & Vitamins</CardTitle>
              <CardDescription>Track your daily supplements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add New Supplement Form */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-lg bg-gray-50">
                <div className="space-y-2">
                  <Label htmlFor="supplement-name">Supplement Name</Label>
                  <Input
                    id="supplement-name"
                    value={newSupplement.name}
                    onChange={(e) => setNewSupplement({ ...newSupplement, name: e.target.value })}
                    placeholder="e.g., Vitamin D, Omega-3"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supplement-dosage">Dosage</Label>
                  <Input
                    id="supplement-dosage"
                    value={newSupplement.dosage}
                    onChange={(e) => setNewSupplement({ ...newSupplement, dosage: e.target.value })}
                    placeholder="e.g., 1000mg, 1 tablet"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supplement-frequency">Frequency</Label>
                  <Input
                    id="supplement-frequency"
                    value={newSupplement.frequency}
                    onChange={(e) => setNewSupplement({ ...newSupplement, frequency: e.target.value })}
                    placeholder="e.g., Once daily, Twice daily"
                  />
                </div>
                <div className="md:col-span-3">
                  <Button onClick={addSupplement} disabled={loading}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Supplement
                  </Button>
                </div>
              </div>

              {/* Existing Supplements */}
              <div className="space-y-2">
                {getItems('dietPlan', 'supplements')?.map((supplement) => (
                  <div key={supplement?.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{supplement?.name}</h4>
                      <p className="text-sm text-gray-600">
                        {supplement?.dosage} - {supplement?.frequency}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeItem('dietPlan', 'supplements', supplement?.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {getItems('dietPlan', 'supplements')?.length === 0 && (
                  <p className="text-center text-gray-500 py-4">No supplements recorded</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Exercise Plan Tab */}
        <TabsContent value="exercise" className="space-y-6">
          {/* Exercise Goals */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Exercise Goals
                  </CardTitle>
                  <CardDescription>Set your fitness objectives</CardDescription>
                </div>
                {(localExerciseData?.goals !== undefined || localExerciseData?.weeklyTarget !== undefined || 
                  localExerciseData?.activities) && (
                  <Button 
                    onClick={() => saveSection('exercise')} 
                    disabled={savingSection === 'exercise'}
                    className="ml-auto"
                  >
                    {savingSection === 'exercise' ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="exercise-goals">Fitness Goals</Label>
                  <Textarea
                    id="exercise-goals"
                    value={getCurrentValue('exercisePlan', 'goals')}
                    onChange={(e) => updateGoal('exercisePlan', e.target.value)}
                    placeholder="e.g., Run 5K, build muscle, improve flexibility..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weekly-target">Weekly Exercise Target (hours)</Label>
                  <Input
                    id="weekly-target"
                    type="number"
                    value={getCurrentValue('exercisePlan', 'weeklyTarget') || 0}
                    onChange={(e) => updateWeeklyTarget(parseInt(e.target.value) || 0)}
                    placeholder="5"
                    min="0"
                    max="50"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exercise Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Exercise Activities
              </CardTitle>
              <CardDescription>Plan your workout routines</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add New Activity Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-gray-50">
                <div className="space-y-2">
                  <Label htmlFor="activity-name">Activity Name</Label>
                  <Input
                    id="activity-name"
                    value={newActivity.name}
                    onChange={(e) => setNewActivity({ ...newActivity, name: e.target.value })}
                    placeholder="e.g., Running, Weight Training, Yoga"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="activity-duration">Duration (minutes)</Label>
                  <Input
                    id="activity-duration"
                    type="number"
                    value={newActivity.duration}
                    onChange={(e) => setNewActivity({ ...newActivity, duration: e.target.value })}
                    placeholder="30"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="activity-intensity">Intensity</Label>
                  <Select value={newActivity.intensity} onValueChange={(value) => setNewActivity({ ...newActivity, intensity: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select intensity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="moderate">Moderate</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="very-high">Very High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="activity-calories">Calories Burned</Label>
                  <Input
                    id="activity-calories"
                    type="number"
                    value={newActivity.calories}
                    onChange={(e) => setNewActivity({ ...newActivity, calories: e.target.value })}
                    placeholder="200"
                  />
                </div>
                <div className="md:col-span-2">
                  <Button onClick={addActivity} disabled={loading}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Activity
                  </Button>
                </div>
              </div>

              {/* Existing Activities */}
              <div className="space-y-2">
                {getItems('exercisePlan', 'activities')?.map((activity) => (
                  <div key={activity?.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-medium">{activity?.name}</h4>
                      <p className="text-sm text-gray-600">
                        Duration: {activity?.duration} min | Intensity: {activity?.intensity} | Calories: {activity?.calories}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeItem('exercisePlan', 'activities', activity?.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                {getItems('exercisePlan', 'activities')?.length === 0 && (
                  <p className="text-center text-gray-500 py-4">No activities planned yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Health Metrics Tab */}
        <TabsContent value="metrics" className="space-y-6">
          {/* Lifestyle Insights from Diet and Exercise */}
          {(() => {
            const insights = calculateInsights();
            return (
              <div className="space-y-4">
                {/* Overall Health Score */}
                <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Award className="h-5 w-5 mr-2 text-blue-600" />
                      Overall Health Score
                    </CardTitle>
                    <CardDescription>Based on your diet and exercise plans</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-4xl font-bold text-blue-600 mb-2">
                          {insights.overall.healthScore}%
                        </div>
                        <p className="text-sm text-gray-600">
                          {insights.overall.healthScore >= 80 ? 'Excellent! Keep up the great work!' :
                           insights.overall.healthScore >= 60 ? 'Good progress! Room for improvement.' :
                           'Let\'s work on improving your lifestyle habits.'}
                        </p>
                      </div>
                      <div className="w-24 h-24 relative">
                        <svg className="transform -rotate-90 w-24 h-24">
                          <circle
                            cx="48"
                            cy="48"
                            r="40"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="none"
                            className="text-gray-200"
                          />
                          <circle
                            cx="48"
                            cy="48"
                            r="40"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="none"
                            strokeDasharray={`${2 * Math.PI * 40}`}
                            strokeDashoffset={`${2 * Math.PI * 40 * (1 - insights.overall.healthScore / 100)}`}
                            className="text-blue-600"
                            strokeLinecap="round"
                          />
                        </svg>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Diet Insights */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center">
                        <Apple className="h-4 w-4 mr-2 text-red-500" />
                        Diet Insights
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Daily Calories</span>
                        <span className="font-semibold">{insights.diet.totalDailyCalories} kcal</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Meals Planned</span>
                        <span className="font-semibold">{insights.diet.averageMealsPerDay} meals</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Water Intake</span>
                        <span className="font-semibold flex items-center">
                          <Droplet className="h-4 w-4 mr-1 text-blue-500" />
                          {insights.diet.waterIntake} glasses/day
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Diet Adherence</span>
                        <span className="font-semibold">{insights.diet.dietAdherence}%</span>
                      </div>
                      <div className="pt-2 border-t">
                        <div className="text-xs text-gray-500 space-y-1">
                          <div className="flex items-center">
                            {insights.diet.hasBreakfast ? (
                              <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                            ) : (
                              <AlertCircle className="h-3 w-3 mr-1 text-gray-400" />
                            )}
                            Breakfast {insights.diet.hasBreakfast ? 'planned' : 'missing'}
                          </div>
                          <div className="flex items-center">
                            {insights.diet.hasLunch ? (
                              <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                            ) : (
                              <AlertCircle className="h-3 w-3 mr-1 text-gray-400" />
                            )}
                            Lunch {insights.diet.hasLunch ? 'planned' : 'missing'}
                          </div>
                          <div className="flex items-center">
                            {insights.diet.hasDinner ? (
                              <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                            ) : (
                              <AlertCircle className="h-3 w-3 mr-1 text-gray-400" />
                            )}
                            Dinner {insights.diet.hasDinner ? 'planned' : 'missing'}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Exercise Insights */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center">
                        <Activity className="h-4 w-4 mr-2 text-green-500" />
                        Exercise Insights
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Total Exercise Hours</span>
                        <span className="font-semibold">{insights.exercise.totalExerciseHours} hrs</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Weekly Target</span>
                        <span className="font-semibold">{insights.exercise.weeklyTarget} hrs/week</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Weekly Progress</span>
                        <span className={`font-semibold ${
                          insights.exercise.weeklyProgress >= 100 ? 'text-green-600' :
                          insights.exercise.weeklyProgress >= 50 ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {insights.exercise.weeklyProgress}%
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Calories Burned</span>
                        <span className="font-semibold flex items-center">
                          <Flame className="h-4 w-4 mr-1 text-orange-500" />
                          {insights.exercise.totalCaloriesBurned} kcal
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Activities Planned</span>
                        <span className="font-semibold">{insights.exercise.exerciseFrequency} activities</span>
                      </div>
                      {insights.exercise.weeklyTarget > 0 && (
                        <div className="pt-2 border-t">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                insights.exercise.weeklyProgress >= 100 ? 'bg-green-500' :
                                insights.exercise.weeklyProgress >= 50 ? 'bg-yellow-500' :
                                'bg-red-500'
                              }`}
                              style={{ width: `${Math.min(insights.exercise.weeklyProgress, 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Additional Statistics */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center">
                        <Zap className="h-4 w-4 mr-2 text-purple-500" />
                        Exercise Intensity
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Low</span>
                          <span className="font-semibold">{insights.exercise.intensityDistribution.low}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Moderate</span>
                          <span className="font-semibold">{insights.exercise.intensityDistribution.moderate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">High</span>
                          <span className="font-semibold">{insights.exercise.intensityDistribution.high}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Very High</span>
                          <span className="font-semibold">{insights.exercise.intensityDistribution.veryHigh}</span>
                        </div>
                        {insights.exercise.averageDuration > 0 && (
                          <div className="pt-2 border-t">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Avg Duration</span>
                              <span className="font-semibold">{insights.exercise.averageDuration} min</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center">
                        <Apple className="h-4 w-4 mr-2 text-red-500" />
                        Diet Details
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Supplements</span>
                          <span className="font-semibold">{insights.diet.supplementsCount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Restrictions</span>
                          <span className="font-semibold">{insights.diet.restrictionsCount}</span>
                        </div>
                        <div className="pt-2 border-t">
                          <div className="text-xs text-gray-500">
                            {insights.diet.totalDailyCalories > 0 ? (
                              <div>
                                <span className="font-medium">Calorie Range: </span>
                                {insights.diet.totalDailyCalories < 1200 ? (
                                  <span className="text-red-600">Below recommended</span>
                                ) : insights.diet.totalDailyCalories > 3000 ? (
                                  <span className="text-yellow-600">Above recommended</span>
                                ) : (
                                  <span className="text-green-600">Healthy range</span>
                                )}
                              </div>
                            ) : (
                              <span>Add meals to track calories</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center">
                        <Target className="h-4 w-4 mr-2 text-blue-500" />
                        Quick Stats
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Activities</span>
                          <span className="font-semibold">{insights.exercise.exerciseFrequency}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Meals</span>
                          <span className="font-semibold">{insights.diet.averageMealsPerDay}</span>
                        </div>
                        <div className="pt-2 border-t">
                          <div className="text-xs text-gray-500">
                            {insights.exercise.weeklyTarget > 0 ? (
                              <div>
                                <span className="font-medium">Exercise Goal: </span>
                                {insights.exercise.weeklyProgress >= 100 ? (
                                  <span className="text-green-600">Achieved! 🎉</span>
                                ) : (
                                  <span>{insights.exercise.weeklyProgress}% complete</span>
                                )}
                              </div>
                            ) : (
                              <span>Set a weekly target to track progress</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Recommendations */}
                <Card className="border-blue-200 bg-blue-50">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center">
                      <BarChart3 className="h-4 w-4 mr-2 text-blue-600" />
                      Personalized Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {insights.overall.recommendations.map((rec, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border ${
                            rec.priority === 'high' ? 'bg-red-50 border-red-200' :
                            rec.priority === 'medium' ? 'bg-yellow-50 border-yellow-200' :
                            'bg-green-50 border-green-200'
                          }`}
                        >
                          <div className="flex items-start">
                            {rec.priority === 'high' ? (
                              <AlertCircle className="h-4 w-4 mr-2 text-red-600 mt-0.5" />
                            ) : rec.priority === 'medium' ? (
                              <AlertCircle className="h-4 w-4 mr-2 text-yellow-600 mt-0.5" />
                            ) : (
                              <CheckCircle className="h-4 w-4 mr-2 text-green-600 mt-0.5" />
                            )}
                            <p className="text-sm flex-1">{rec.message}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            );
          })()}

          {/* Manual Health Metrics Entry */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Manual Health Metrics Tracking
                  </CardTitle>
                  <CardDescription>Record and track your health indicators over time</CardDescription>
                </div>
                {(() => {
                  // Check if there are any unsaved metrics
                  const hasUnsavedMetrics = localMetricsData && Object.keys(localMetricsData).length > 0;
                  return hasUnsavedMetrics && (
                    <Button 
                      onClick={() => saveSection('metrics')} 
                      disabled={savingSection === 'metrics'}
                      className="ml-auto"
                    >
                      {savingSection === 'metrics' ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  );
                })()}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Add New Metric Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-gray-50">
                <div className="space-y-2">
                  <Label htmlFor="metric-type">Metric Type *</Label>
                  <Select value={newMetric.type} onValueChange={(value) => setNewMetric({ ...newMetric, type: value, value: '' })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select metric type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight">Weight (kg/lbs)</SelectItem>
                      <SelectItem value="bloodPressure">Blood Pressure (mmHg)</SelectItem>
                      <SelectItem value="heartRate">Heart Rate (bpm)</SelectItem>
                      <SelectItem value="sleepHours">Sleep Hours</SelectItem>
                      <SelectItem value="bloodSugar">Blood Sugar (mg/dL)</SelectItem>
                      <SelectItem value="temperature">Body Temperature (°F/°C)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="metric-value">Value *</Label>
                  <Input
                    id="metric-value"
                    value={newMetric.value}
                    onChange={(e) => setNewMetric({ ...newMetric, value: e.target.value })}
                    placeholder={
                      newMetric.type === 'weight' ? 'e.g., 70 kg or 154 lbs' :
                      newMetric.type === 'bloodPressure' ? 'e.g., 120/80' :
                      newMetric.type === 'heartRate' ? 'e.g., 72 bpm' :
                      newMetric.type === 'sleepHours' ? 'e.g., 7.5 hours' :
                      newMetric.type === 'bloodSugar' ? 'e.g., 100 mg/dL' :
                      newMetric.type === 'temperature' ? 'e.g., 98.6°F' :
                      'Enter value'
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="metric-date">Date *</Label>
                  <Input
                    id="metric-date"
                    type="date"
                    value={newMetric.date}
                    onChange={(e) => setNewMetric({ ...newMetric, date: e.target.value })}
                    max={new Date().toISOString().split('T')[0]}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="metric-notes">Notes</Label>
                  <Input
                    id="metric-notes"
                    value={newMetric.notes}
                    onChange={(e) => setNewMetric({ ...newMetric, notes: e.target.value })}
                    placeholder="e.g., Morning reading, After exercise, etc."
                  />
                </div>
                <div className="md:col-span-2">
                  <Button onClick={addHealthMetric} disabled={loading || !newMetric.type || !newMetric.value || !newMetric.date}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Metric
                  </Button>
                </div>
              </div>

              {/* Visualizations Section */}
              {(() => {
                const hasAnyMetrics = ['weight', 'bloodPressure', 'heartRate', 'sleepHours', 'bloodSugar', 'temperature']
                  .some(type => getItems('healthMetrics', type).length > 0);
                
                if (!hasAnyMetrics) {
                  return (
                    <Card className="bg-gray-50">
                      <CardContent className="py-8 text-center">
                        <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">No health metrics recorded yet</p>
                        <p className="text-sm text-gray-400 mt-2">Add metrics above to see visualizations</p>
                      </CardContent>
                    </Card>
                  );
                }

                return (
                  <div className="space-y-6">
                    {/* Charts Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                      {['weight', 'bloodPressure', 'heartRate', 'sleepHours', 'bloodSugar', 'temperature'].map((metricType) => {
                        const metrics = getItems('healthMetrics', metricType);
                        const chartData = prepareChartData(metricType);
                        const displayName = metricType
                          .replace(/([A-Z])/g, ' $1')
                          .replace(/^./, str => str.toUpperCase());
                        
                        if (chartData.length === 0) return null;

                        return (
                          <Card key={metricType} className="border">
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base flex items-center">
                                {metricType === 'weight' && <Target className="h-4 w-4 mr-2" />}
                                {metricType === 'bloodPressure' && <Heart className="h-4 w-4 mr-2" />}
                                {metricType === 'heartRate' && <Activity className="h-4 w-4 mr-2" />}
                                {metricType === 'sleepHours' && <Clock className="h-4 w-4 mr-2" />}
                                {metricType === 'bloodSugar' && <TrendingUp className="h-4 w-4 mr-2" />}
                                {metricType === 'temperature' && <Flame className="h-4 w-4 mr-2" />}
                                {displayName} Trend
                              </CardTitle>
                              {metrics.length > 0 && (
                                <CardDescription>
                                  Latest: {metrics[metrics.length - 1]?.value} 
                                  {metrics[metrics.length - 1]?.date && 
                                    ` (${new Date(metrics[metrics.length - 1].date).toLocaleDateString()})`
                                  }
                                </CardDescription>
                              )}
                            </CardHeader>
                            <CardContent>
                              {metricType === 'bloodPressure' ? (
                                // Special chart for blood pressure (two lines)
                                <ResponsiveContainer width="100%" height={180} className="min-h-[180px] sm:h-[200px]">
                                  <AreaChart data={chartData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis 
                                      dataKey="date" 
                                      angle={-45}
                                      textAnchor="end"
                                      height={60}
                                      interval={0}
                                      fontSize={10}
                                    />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Area 
                                      type="monotone" 
                                      dataKey="systolic" 
                                      stroke="#ef4444" 
                                      fill="#ef4444" 
                                      fillOpacity={0.6}
                                      name="Systolic"
                                    />
                                    <Area 
                                      type="monotone" 
                                      dataKey="diastolic" 
                                      stroke="#3b82f6" 
                                      fill="#3b82f6" 
                                      fillOpacity={0.6}
                                      name="Diastolic"
                                    />
                                  </AreaChart>
                                </ResponsiveContainer>
                              ) : (
                                // Regular line chart for other metrics
                                <ResponsiveContainer width="100%" height={180} className="min-h-[180px] sm:h-[200px]">
                                  <LineChart data={chartData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis 
                                      dataKey="date" 
                                      angle={-45}
                                      textAnchor="end"
                                      height={60}
                                      interval={0}
                                      fontSize={10}
                                    />
                                    <YAxis />
                                    <Tooltip 
                                      formatter={(value) => {
                                        if (metricType === 'weight') return `${value} ${chartData[0]?.rawValue?.includes('kg') ? 'kg' : 'lbs'}`;
                                        if (metricType === 'temperature') return `${value}°`;
                                        if (metricType === 'sleepHours') return `${value} hrs`;
                                        if (metricType === 'heartRate') return `${value} bpm`;
                                        if (metricType === 'bloodSugar') return `${value} mg/dL`;
                                        return value;
                                      }}
                                    />
                                    <Legend />
                                    <Line 
                                      type="monotone" 
                                      dataKey="value" 
                                      stroke="#3b82f6" 
                                      strokeWidth={2}
                                      dot={{ r: 4 }}
                                      activeDot={{ r: 6 }}
                                      name={displayName}
                                    />
                                  </LineChart>
                                </ResponsiveContainer>
                              )}
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>

                    {/* Detailed List View */}
                    <Card>
                      <CardHeader>
                        <CardTitle>All Metrics Records</CardTitle>
                        <CardDescription>View and manage all your health metric entries</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {['weight', 'bloodPressure', 'heartRate', 'sleepHours', 'bloodSugar', 'temperature'].map((metricType) => {
                            const metrics = getItems('healthMetrics', metricType);
                            const displayName = metricType
                              .replace(/([A-Z])/g, ' $1')
                              .replace(/^./, str => str.toUpperCase());
                            
                            return (
                              <div key={metricType} className="space-y-2">
                                <h4 className="font-medium text-sm text-gray-700 mb-2">{displayName}</h4>
                                <div className="space-y-1 max-h-64 overflow-y-auto">
                                  {metrics.length > 0 ? (
                                    metrics
                                      .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0))
                                      .map((metric) => (
                                        <div key={metric?.id} className="flex items-center justify-between p-2 border rounded hover:bg-gray-50">
                                          <div className="flex-1">
                                            <div className="flex items-center space-x-2">
                                              <span className="font-semibold">{metric?.value}</span>
                                              {metric?.date && (
                                                <span className="text-xs text-gray-500">
                                                  {new Date(metric.date).toLocaleDateString('en-US', { 
                                                    month: 'short', 
                                                    day: 'numeric'
                                                  })}
                                                </span>
                                              )}
                                            </div>
                                            {metric?.notes && (
                                              <p className="text-xs text-gray-600 mt-1">{metric.notes}</p>
                                            )}
                                          </div>
                                          <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={() => removeItem('healthMetrics', metricType, metric?.id)}
                                            className="ml-2 h-8 w-8 p-0"
                                          >
                                            <Trash2 className="h-3 w-3 text-red-500" />
                                          </Button>
                                        </div>
                                      ))
                                  ) : (
                                    <p className="text-xs text-gray-500 py-2 text-center">No records</p>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                );
              })()}

              {/* Summary Statistics */}
              {getItems('healthMetrics', 'weight').length > 0 && (
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="text-base">Quick Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      {getItems('healthMetrics', 'weight').length > 0 && (
                        <div>
                          <p className="text-gray-600">Weight Records</p>
                          <p className="font-semibold text-lg">{getItems('healthMetrics', 'weight').length}</p>
                        </div>
                      )}
                      {getItems('healthMetrics', 'bloodPressure').length > 0 && (
                        <div>
                          <p className="text-gray-600">BP Records</p>
                          <p className="font-semibold text-lg">{getItems('healthMetrics', 'bloodPressure').length}</p>
                        </div>
                      )}
                      {getItems('healthMetrics', 'heartRate').length > 0 && (
                        <div>
                          <p className="text-gray-600">Heart Rate Records</p>
                          <p className="font-semibold text-lg">{getItems('healthMetrics', 'heartRate').length}</p>
                        </div>
                      )}
                      {getItems('healthMetrics', 'sleepHours').length > 0 && (
                        <div>
                          <p className="text-gray-600">Sleep Records</p>
                          <p className="font-semibold text-lg">{getItems('healthMetrics', 'sleepHours').length}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LifestylePlans;
