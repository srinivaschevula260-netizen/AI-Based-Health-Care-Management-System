import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Heart, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle,
  User,
  Mail,
  Phone,
  Calendar,
  RotateCcw
} from 'lucide-react';
import { getAllUsers, deactivateUser, activateUser } from '../../utils/database';

const PatientManagement = ({ onUpdate }) => {
  const { createPatient: createPatientAuth } = useAuth();
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form state for creating new patient
  const [newPatient, setNewPatient] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    emergencyContact: ''
  });

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const allUsers = await getAllUsers();
      const patientUsers = allUsers.filter(user => user.role === 'patient');
      setPatients(patientUsers);
    } catch (error) {
      console.error('Error fetching patients:', error);
      setError('Failed to load patients');
    }
  };

  const handleCreatePatient = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    // Validate form
    if (!newPatient.firstName || !newPatient.lastName || !newPatient.email || !newPatient.password) {
      setError('Please fill in all required fields');
      setLoading(false);
      return;
    }

    if (newPatient.password.length < 6) {
      setError('Password must be at least 6 characters');
      setLoading(false);
      return;
    }

    try {
      const patientData = {
        firstName: newPatient.firstName,
        lastName: newPatient.lastName,
        phone: newPatient.phone || '',
        dateOfBirth: newPatient.dateOfBirth || '',
        address: newPatient.address || '',
        emergencyContact: newPatient.emergencyContact || '',
        role: 'patient'
      };

      await createPatientAuth(newPatient.email, newPatient.password, patientData);
      setSuccess('Patient account created successfully!');
      
      // Reset form
      setNewPatient({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        phone: '',
        dateOfBirth: '',
        address: '',
        emergencyContact: ''
      });
      
      // Refresh patients list
      await fetchPatients();
      // Notify parent to refresh stats
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error creating patient:', error);
      setError('Failed to create patient account. Email may already be in use.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeactivatePatient = async (patientId) => {
    if (!window.confirm('Are you sure you want to deactivate this patient?')) {
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      await deactivateUser(patientId);
      setSuccess('Patient deactivated successfully!');
      await fetchPatients();
      // Notify parent to refresh stats
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error deactivating patient:', error);
      setError('Failed to deactivate patient');
    } finally {
      setLoading(false);
    }
  };

  const handleActivatePatient = async (patientId) => {
    if (!window.confirm('Are you sure you want to activate this patient?')) {
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      await activateUser(patientId);
      setSuccess('Patient activated successfully!');
      await fetchPatients();
      // Notify parent to refresh stats
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error activating patient:', error);
      setError('Failed to activate patient');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold">Patient Management</h3>
        <p className="text-sm text-gray-600">Create and manage patient accounts</p>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">{success}</AlertDescription>
        </Alert>
      )}

      {/* Create New Patient */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Plus className="h-5 w-5 mr-2" />
            Create New Patient Account
          </CardTitle>
          <CardDescription>Add a new patient to the system</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreatePatient} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={newPatient.firstName}
                  onChange={(e) => setNewPatient({ ...newPatient, firstName: e.target.value })}
                  required
                  placeholder="First name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={newPatient.lastName}
                  onChange={(e) => setNewPatient({ ...newPatient, lastName: e.target.value })}
                  required
                  placeholder="Last name"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={newPatient.email}
                  onChange={(e) => setNewPatient({ ...newPatient, email: e.target.value })}
                  required
                  placeholder="patient@example.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  value={newPatient.password}
                  onChange={(e) => setNewPatient({ ...newPatient, password: e.target.value })}
                  required
                  placeholder="Minimum 6 characters"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={newPatient.phone}
                  onChange={(e) => setNewPatient({ ...newPatient, phone: e.target.value })}
                  placeholder="Phone number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dateOfBirth">Date of Birth</Label>
                <Input
                  id="dateOfBirth"
                  type="date"
                  value={newPatient.dateOfBirth}
                  onChange={(e) => setNewPatient({ ...newPatient, dateOfBirth: e.target.value })}
                  placeholder="Date of birth"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={newPatient.address}
                  onChange={(e) => setNewPatient({ ...newPatient, address: e.target.value })}
                  placeholder="Home address"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyContact">Emergency Contact</Label>
                <Input
                  id="emergencyContact"
                  value={newPatient.emergencyContact}
                  onChange={(e) => setNewPatient({ ...newPatient, emergencyContact: e.target.value })}
                  placeholder="Emergency contact name/phone"
                />
              </div>
            </div>

            <Button type="submit" disabled={loading} className="w-full">
              {loading ? 'Creating Patient Account...' : 'Create Patient Account'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Existing Patients */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Heart className="h-5 w-5 mr-2" />
            Existing Patients
          </CardTitle>
          <CardDescription>Manage current patient accounts</CardDescription>
        </CardHeader>
        <CardContent>
          {patients.length === 0 ? (
            <div className="text-center py-8">
              <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No patients found</p>
              <p className="text-sm text-gray-400">Create your first patient account above</p>
            </div>
          ) : (
            <div className="space-y-4">
              {patients.map((patient) => (
                <div key={patient.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 sm:p-4 border rounded-lg gap-3 sm:gap-0">
                  <div className="flex items-center space-x-3 sm:space-x-4 flex-1 min-w-0">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-pink-600" />
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className="font-medium text-sm sm:text-base truncate">
                        {patient.firstName} {patient.lastName}
                      </h4>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 text-xs sm:text-sm text-gray-600 mt-1 gap-1 sm:gap-0">
                        <div className="flex items-center truncate">
                          <Mail className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
                          <span className="truncate">{patient.email}</span>
                        </div>
                        {patient.phone && (
                          <div className="flex items-center">
                            <Phone className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
                            <span className="truncate">{patient.phone}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 text-xs sm:text-sm text-gray-500 mt-1 gap-1 sm:gap-0">
                        {patient.dateOfBirth && (
                          <span className="truncate">DOB: {new Date(patient.dateOfBirth).toLocaleDateString()}</span>
                        )}
                        {patient.address && (
                          <span className="truncate">Address: {patient.address}</span>
                        )}
                      </div>
                      {patient.emergencyContact && (
                        <div className="text-xs sm:text-sm text-gray-500 mt-1 truncate">
                          Emergency: {patient.emergencyContact}
                        </div>
                      )}
                      <div className="flex items-center text-xs sm:text-sm text-gray-500 mt-1">
                        <Calendar className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
                        Joined: {new Date(patient.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      patient.isActive 
                        ? 'text-green-600 bg-green-100' 
                        : 'text-red-600 bg-red-100'
                    }`}>
                      {patient.isActive ? 'Active' : 'Inactive'}
                    </span>
                    {patient.isActive ? (
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDeactivatePatient(patient.id)}
                        disabled={loading}
                        title="Deactivate Patient"
                        className="h-8 w-8 p-0"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleActivatePatient(patient.id)}
                        disabled={loading}
                        title="Activate Patient"
                        className="text-green-600 border-green-600 hover:bg-green-50 h-8 w-8 p-0"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PatientManagement;

