import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { getAllUsers } from '../../utils/database';
import { Users, UserCheck, UserX, TrendingUp, Activity } from 'lucide-react';

const Analytics = () => {
  const [analyticsData, setAnalyticsData] = useState({
    usersOverTime: [],
    roleDistribution: [],
    activeVsInactive: [],
    monthlyGrowth: []
  });
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    patients: 0,
    doctors: 0,
    admins: 0,
    activePatients: 0,
    inactivePatients: 0,
    activeDoctors: 0,
    inactiveDoctors: 0
  });

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const allUsers = await getAllUsers();

      // Calculate summary
      const totalUsers = allUsers.length;
      const activeUsers = allUsers.filter(u => u.isActive !== false).length;
      const inactiveUsers = totalUsers - activeUsers;
      const patients = allUsers.filter(u => u.role === 'patient');
      const doctors = allUsers.filter(u => u.role === 'doctor');
      const admins = allUsers.filter(u => u.role === 'admin');
      
      const activePatients = patients.filter(u => u.isActive !== false).length;
      const inactivePatients = patients.length - activePatients;
      const activeDoctors = doctors.filter(u => u.isActive !== false).length;
      const inactiveDoctors = doctors.length - activeDoctors;

      setSummary({
        totalUsers,
        activeUsers,
        inactiveUsers,
        patients: patients.length,
        doctors: doctors.length,
        admins: admins.length,
        activePatients,
        inactivePatients,
        activeDoctors,
        inactiveDoctors
      });

      // Process users over time
      const usersByDate = {};
      allUsers.forEach(user => {
        if (user.createdAt) {
          const date = new Date(user.createdAt);
          const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          if (!usersByDate[monthKey]) {
            usersByDate[monthKey] = { patients: 0, doctors: 0, admins: 0, total: 0 };
          }
          usersByDate[monthKey][user.role + 's'] = (usersByDate[monthKey][user.role + 's'] || 0) + 1;
          usersByDate[monthKey].total += 1;
        }
      });

      // Sort by date and format for chart
      const sortedDates = Object.keys(usersByDate).sort();
      const usersOverTime = sortedDates.map(date => {
        const [year, month] = date.split('-');
        const monthName = new Date(year, parseInt(month) - 1).toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        return {
          month: monthName,
          date,
          patients: usersByDate[date].patients || 0,
          doctors: usersByDate[date].doctors || 0,
          admins: usersByDate[date].admins || 0,
          total: usersByDate[date].total || 0
        };
      });

      // Role distribution
      const roleDistribution = [
        { name: 'Patients', value: patients, color: COLORS[0] },
        { name: 'Doctors', value: doctors, color: COLORS[1] },
        { name: 'Admins', value: admins, color: COLORS[2] }
      ].filter(item => item.value > 0);

      // Active vs Inactive
      const activeVsInactive = [
        { name: 'Active', value: activeUsers, color: COLORS[1] },
        { name: 'Inactive', value: inactiveUsers, color: COLORS[3] }
      ].filter(item => item.value > 0);

      // Monthly growth (cumulative)
      let cumulativeTotal = 0;
      const monthlyGrowth = usersOverTime.map(item => {
        cumulativeTotal += item.total;
        return {
          month: item.month,
          date: item.date,
          users: cumulativeTotal
        };
      });

      setAnalyticsData({
        usersOverTime,
        roleDistribution,
        activeVsInactive,
        monthlyGrowth
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Activity className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-500">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold">Analytics & Reports</h3>
        <p className="text-sm text-gray-600">System metrics and user statistics</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.totalUsers}</div>
            <p className="text-xs text-muted-foreground">All registered users</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{summary.activeUsers}</div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inactive Users</CardTitle>
            <UserX className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{summary.inactiveUsers}</div>
            <p className="text-xs text-muted-foreground">Deactivated accounts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patients</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{summary.patients}</div>
            <p className="text-xs text-muted-foreground">Registered patients</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Doctors</CardTitle>
            <Users className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{summary.doctors}</div>
            <p className="text-xs text-muted-foreground">Healthcare providers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Admins</CardTitle>
            <Users className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{summary.admins}</div>
            <p className="text-xs text-muted-foreground">Administrators</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* User Growth Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2" />
              User Growth Over Time
            </CardTitle>
            <CardDescription>Cumulative user registration by month</CardDescription>
          </CardHeader>
          <CardContent>
            {analyticsData.monthlyGrowth.length > 0 ? (
              <ResponsiveContainer width="100%" height={250} className="min-h-[250px] sm:h-[300px]">
                <AreaChart data={analyticsData.monthlyGrowth}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    interval={0}
                  />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="users" 
                    stroke="#3b82f6" 
                    fill="#3b82f6" 
                    fillOpacity={0.6}
                    name="Total Users"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Role Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Role Distribution</CardTitle>
            <CardDescription>User distribution by role</CardDescription>
          </CardHeader>
          <CardContent>
            {analyticsData.roleDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={250} className="min-h-[250px] sm:h-[300px]">
                <PieChart>
                  <Pie
                    data={analyticsData.roleDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {analyticsData.roleDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active vs Inactive Users */}
        <Card>
          <CardHeader>
            <CardTitle>Active vs Inactive Users</CardTitle>
            <CardDescription>User account status distribution</CardDescription>
          </CardHeader>
          <CardContent>
            {analyticsData.activeVsInactive.length > 0 ? (
              <ResponsiveContainer width="100%" height={250} className="min-h-[250px] sm:h-[300px]">
                <PieChart>
                  <Pie
                    data={analyticsData.activeVsInactive}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {analyticsData.activeVsInactive.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Users Over Time by Role */}
        <Card>
          <CardHeader>
            <CardTitle>New Users by Role Over Time</CardTitle>
            <CardDescription>Monthly registration breakdown by role</CardDescription>
          </CardHeader>
          <CardContent>
            {analyticsData.usersOverTime.length > 0 ? (
              <ResponsiveContainer width="100%" height={250} className="min-h-[250px] sm:h-[300px]">
                <BarChart data={analyticsData.usersOverTime}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    interval={0}
                    tick={{ fontSize: 10 }}
                  />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="patients" stackId="a" fill="#3b82f6" name="Patients" />
                  <Bar dataKey="doctors" stackId="a" fill="#10b981" name="Doctors" />
                  <Bar dataKey="admins" stackId="a" fill="#f59e0b" name="Admins" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* User Registration Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Registration Trend</CardTitle>
            <CardDescription>New user registrations per month</CardDescription>
          </CardHeader>
          <CardContent>
            {analyticsData.usersOverTime.length > 0 ? (
              <ResponsiveContainer width="100%" height={250} className="min-h-[250px] sm:h-[300px]">
                <LineChart data={analyticsData.usersOverTime}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    interval={0}
                    tick={{ fontSize: 10 }}
                  />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="total" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    name="New Users"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active vs Inactive by Role */}
        <Card>
          <CardHeader>
            <CardTitle>Active vs Inactive by Role</CardTitle>
            <CardDescription>Status breakdown by user role</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                  <span className="font-medium">Patients</span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-green-600">
                    Active: {summary.activePatients}
                  </span>
                  <span className="text-sm text-red-600">
                    Inactive: {summary.inactivePatients}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                  <span className="font-medium">Doctors</span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-green-600">
                    Active: {summary.activeDoctors}
                  </span>
                  <span className="text-sm text-red-600">
                    Inactive: {summary.inactiveDoctors}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-600 rounded-full"></div>
                  <span className="font-medium">Admins</span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-green-600">
                    Active: {summary.admins}
                  </span>
                  <span className="text-sm text-red-600">
                    Inactive: 0
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Analytics;

