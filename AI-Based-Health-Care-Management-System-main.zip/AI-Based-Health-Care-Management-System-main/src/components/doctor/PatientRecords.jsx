import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  Search, 
  FileText, 
  Heart, 
  Pill, 
  AlertTriangle,
  Calendar,
  User,
  Phone,
  Mail,
  MapPin,
  Clock,
  Activity,
  Apple,
  Target,
  Droplet,
  Flame,
  TrendingUp,
  Zap
} from 'lucide-react';
import { getAllUsers, getAppointments, getMedicalHistory, getPatientMedicalHistory, getAllPatientsMedicalHistory } from '../../utils/database';

const PatientRecords = () => {
  const { currentUser } = useAuth();
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [patientAppointments, setPatientAppointments] = useState([]);
  const [patientMedicalHistory, setPatientMedicalHistory] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchPatients();
  }, [currentUser]);

  const fetchPatients = async () => {
    try {
      const allUsers = await getAllUsers();
      const patientUsers = allUsers.filter(user => user.role === 'patient' && user.isActive);
      setPatients(patientUsers);
    } catch (error) {
      console.error('Error fetching patients:', error);
      setError('Failed to load patients');
    }
  };

  const fetchPatientDetails = async (patientId) => {
    setLoading(true);
    setError('');

    try {
      // Fetch patient appointments with this doctor
      const allAppointments = await getAppointments(currentUser.uid, 'doctor');
      const patientApts = allAppointments.filter(apt => apt.patientId === patientId);
      setPatientAppointments(patientApts);

      // Fetch patient medical history from new database structure
      let medicalHistory = await getPatientMedicalHistory(patientId);
      if (!medicalHistory) {
        // Fallback to old structure (users/{userId}/medicalHistory)
        medicalHistory = await getMedicalHistory(patientId);
      }
      
      // Also check if lifestyle plans are in the old structure
      if (medicalHistory && !medicalHistory.lifestylePlans) {
        const oldMedicalHistory = await getMedicalHistory(patientId);
        if (oldMedicalHistory && oldMedicalHistory.lifestylePlans) {
          medicalHistory.lifestylePlans = oldMedicalHistory.lifestylePlans;
        }
      }
      
      setPatientMedicalHistory(medicalHistory);

    } catch (error) {
      console.error('Error fetching patient details:', error);
      setError('Failed to load patient details');
    } finally {
      setLoading(false);
    }
  };

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
    fetchPatientDetails(patient.id);
    setActiveTab('overview');
  };

  const filteredPatients = patients.filter(patient => {
    const fullName = `${patient.firstName} ${patient.lastName}`.toLowerCase();
    const email = patient.email.toLowerCase();
    return fullName.includes(searchTerm.toLowerCase()) || 
           email.includes(searchTerm.toLowerCase());
  });

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return 'text-blue-600 bg-blue-100';
      case 'completed': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      case 'no-show': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h3 className="text-base sm:text-lg font-semibold">Patient Records</h3>
          <p className="text-xs sm:text-sm text-gray-600">View and manage patient information and medical history</p>
        </div>
        <div className="relative w-full sm:w-auto">
          <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
          <Input
            placeholder="Search patients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full sm:w-64"
          />
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Patient List */}
        <div className="lg:col-span-1 order-2 lg:order-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Patients ({filteredPatients.length})
              </CardTitle>
              <CardDescription>Select a patient to view their records</CardDescription>
            </CardHeader>
            <CardContent>
              {filteredPatients.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No patients found</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredPatients.map((patient) => (
                    <div
                      key={patient.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedPatient?.id === patient.id
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => handlePatientSelect(patient)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <User className="h-4 w-4 text-green-600" />
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {patient.firstName} {patient.lastName}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {patient.email}
                          </p>
                          {patient.phone && (
                            <p className="text-xs text-gray-500">
                              {patient.phone}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Patient Details */}
        <div className="lg:col-span-2 order-1 lg:order-2">
          {selectedPatient ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  {selectedPatient.firstName} {selectedPatient.lastName}
                </CardTitle>
                <CardDescription>Patient medical records and history</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
                    <TabsTrigger value="overview" className="text-xs sm:text-sm py-2 sm:py-1.5">Overview</TabsTrigger>
                    <TabsTrigger value="appointments" className="text-xs sm:text-sm py-2 sm:py-1.5">Appointments</TabsTrigger>
                    <TabsTrigger value="medical" className="text-xs sm:text-sm py-2 sm:py-1.5">Medical</TabsTrigger>
                    <TabsTrigger value="lifestyle" className="text-xs sm:text-sm py-2 sm:py-1.5">Lifestyle</TabsTrigger>
                  </TabsList>

                  {/* Overview Tab */}
                  <TabsContent value="overview" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium">Personal Information</Label>
                          <div className="mt-2 space-y-2">
                            <div className="flex items-center space-x-2">
                              <Mail className="h-4 w-4 text-gray-400" />
                              <span className="text-sm">{selectedPatient.email}</span>
                            </div>
                            {selectedPatient.phone && (
                              <div className="flex items-center space-x-2">
                                <Phone className="h-4 w-4 text-gray-400" />
                                <span className="text-sm">{selectedPatient.phone}</span>
                              </div>
                            )}
                            {selectedPatient.dateOfBirth && (
                              <div className="flex items-center space-x-2">
                                <Calendar className="h-4 w-4 text-gray-400" />
                                <span className="text-sm">
                                  DOB: {formatDate(selectedPatient.dateOfBirth)}
                                </span>
                              </div>
                            )}
                            {selectedPatient.address && (
                              <div className="flex items-center space-x-2">
                                <MapPin className="h-4 w-4 text-gray-400" />
                                <span className="text-sm">{selectedPatient.address}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <div>
                          <Label className="text-sm font-medium">Emergency Contact</Label>
                          {selectedPatient.emergencyContact ? (
                            <p className="text-sm mt-1">{selectedPatient.emergencyContact}</p>
                          ) : (
                            <p className="text-sm text-gray-500 mt-1">Not provided</p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium">Appointment Summary</Label>
                          <div className="mt-2 space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Total Appointments:</span>
                              <span className="font-medium">{patientAppointments.length}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Completed:</span>
                              <span className="font-medium text-green-600">
                                {patientAppointments.filter(apt => apt.status === 'completed').length}
                              </span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Last Visit:</span>
                              <span className="font-medium">
                                {patientAppointments.length > 0 
                                  ? formatDate(patientAppointments[patientAppointments.length - 1].date)
                                  : 'Never'
                                }
                              </span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label className="text-sm font-medium">Account Status</Label>
                          <div className="mt-2">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              selectedPatient.isActive 
                                ? 'text-green-600 bg-green-100' 
                                : 'text-red-600 bg-red-100'
                            }`}>
                              {selectedPatient.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  {/* Appointments Tab */}
                  <TabsContent value="appointments" className="space-y-4">
                    {patientAppointments.length === 0 ? (
                      <div className="text-center py-8">
                        <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">No appointments found</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {patientAppointments
                          .sort((a, b) => new Date(b.date) - new Date(a.date))
                          .map((appointment) => (
                            <div key={appointment.id} className="border rounded-lg p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-medium">
                                    {formatDate(appointment.date)} at {formatTime(appointment.time)}
                                  </h4>
                                  {appointment.notes && (
                                    <p className="text-sm text-gray-600 mt-1">
                                      Notes: {appointment.notes}
                                    </p>
                                  )}
                                  {appointment.feedback && (
                                    <div className="mt-2 text-sm">
                                      <p className="text-gray-700">
                                        <strong>Diagnosis:</strong> {appointment.feedback.diagnosis}
                                      </p>
                                      {appointment.feedback.treatment && (
                                        <p className="text-gray-700">
                                          <strong>Treatment:</strong> {appointment.feedback.treatment}
                                        </p>
                                      )}
                                    </div>
                                  )}
                                </div>
                                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appointment.status)}`}>
                                  {appointment.status}
                                </span>
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </TabsContent>

                  {/* Medical History Tab */}
                  <TabsContent value="medical" className="space-y-4">
                    {patientMedicalHistory ? (
                      <div className="space-y-6">
                        {/* Health Summary for Doctor */}
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h4 className="font-semibold text-blue-900 mb-3 flex items-center">
                            <Activity className="h-5 w-5 mr-2" />
                            Health Summary
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-blue-800">Active Conditions:</span>
                              <span className="ml-2 text-blue-700">
                                {patientMedicalHistory.conditions?.filter(c => c.status === 'active').length || 0}
                              </span>
                            </div>
                            <div>
                              <span className="font-medium text-blue-800">Current Medications:</span>
                              <span className="ml-2 text-blue-700">
                                {patientMedicalHistory.medications?.length || 0}
                              </span>
                            </div>
                            <div>
                              <span className="font-medium text-blue-800">Known Allergies:</span>
                              <span className="ml-2 text-blue-700">
                                {patientMedicalHistory.allergies?.length || 0}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Medical Conditions */}
                        {patientMedicalHistory.conditions && patientMedicalHistory.conditions.length > 0 && (
                          <div>
                            <Label className="text-sm font-medium flex items-center">
                              <Heart className="h-4 w-4 mr-2" />
                              Medical Conditions ({patientMedicalHistory.conditions.length})
                            </Label>
                            <div className="mt-2 space-y-3">
                              {patientMedicalHistory.conditions.map((condition, index) => (
                                <div key={index} className="p-4 bg-white border rounded-lg shadow-sm">
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-2">
                                        <h5 className="font-semibold text-lg">{condition.name}</h5>
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                          condition.status === 'active' ? 'bg-red-100 text-red-800' :
                                          condition.status === 'resolved' ? 'bg-green-100 text-green-800' :
                                          condition.status === 'chronic' ? 'bg-orange-100 text-orange-800' :
                                          'bg-blue-100 text-blue-800'
                                        }`}>
                                          {condition.status}
                                        </span>
                                      </div>
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                                        <div>
                                          <span className="font-medium text-gray-700">Diagnosed:</span>
                                          <span className="ml-2 text-gray-600">{formatDate(condition.diagnosisDate)}</span>
                                        </div>
                                        <div>
                                          <span className="font-medium text-gray-700">Duration:</span>
                                          <span className="ml-2 text-gray-600">
                                            {condition.diagnosisDate ? 
                                              `${Math.floor((new Date() - new Date(condition.diagnosisDate)) / (1000 * 60 * 60 * 24 * 365.25))} years` : 
                                              'Unknown'
                                            }
                                          </span>
                                        </div>
                                      </div>
                                      {condition.notes && (
                                        <div className="mt-2 p-2 bg-gray-50 rounded text-sm">
                                          <span className="font-medium text-gray-700">Notes:</span>
                                          <p className="text-gray-600 mt-1">{condition.notes}</p>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Medications */}
                        {patientMedicalHistory.medications && patientMedicalHistory.medications.length > 0 && (
                          <div>
                            <Label className="text-sm font-medium flex items-center">
                              <Pill className="h-4 w-4 mr-2" />
                              Current Medications ({patientMedicalHistory.medications.length})
                            </Label>
                            <div className="mt-2 space-y-3">
                              {patientMedicalHistory.medications.map((medication, index) => (
                                <div key={index} className="p-4 bg-white border rounded-lg shadow-sm">
                                  <div className="flex items-start justify-between">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-2">
                                        <h5 className="font-semibold text-lg">{medication.name}</h5>
                                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                          Current Medication
                                        </span>
                                      </div>
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm mb-2">
                                        <div>
                                          <span className="font-medium text-gray-700">Dosage:</span>
                                          <span className="ml-2 text-gray-600">{medication.dosage}</span>
                                        </div>
                                        <div>
                                          <span className="font-medium text-gray-700">Frequency:</span>
                                          <span className="ml-2 text-gray-600">{medication.frequency}</span>
                                        </div>
                                        <div>
                                          <span className="font-medium text-gray-700">Start Date:</span>
                                          <span className="ml-2 text-gray-600">{formatDate(medication.startDate)}</span>
                                        </div>
                                        <div>
                                          <span className="font-medium text-gray-700">Prescribed By:</span>
                                          <span className="ml-2 text-gray-600">{medication.prescribedBy || 'Not specified'}</span>
                                        </div>
                                      </div>
                                      {medication.endDate && (
                                        <div className="text-sm">
                                          <span className="font-medium text-gray-700">End Date:</span>
                                          <span className="ml-2 text-gray-600">{formatDate(medication.endDate)}</span>
                                        </div>
                                      )}
                                      {medication.startDate && (
                                        <div className="mt-2 text-sm">
                                          <span className="font-medium text-gray-700">Duration:</span>
                                          <span className="ml-2 text-gray-600">
                                            {medication.endDate ? 
                                              `${Math.floor((new Date(medication.endDate) - new Date(medication.startDate)) / (1000 * 60 * 60 * 24))} days` :
                                              `${Math.floor((new Date() - new Date(medication.startDate)) / (1000 * 60 * 60 * 24))} days (ongoing)`
                                            }
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Allergies */}
                        {patientMedicalHistory.allergies && patientMedicalHistory.allergies.length > 0 && (
                          <div>
                            <Label className="text-sm font-medium flex items-center">
                              <AlertTriangle className="h-4 w-4 mr-2" />
                              Allergies
                            </Label>
                            <div className="mt-2 space-y-2">
                              {patientMedicalHistory.allergies.map((allergy, index) => (
                                <div key={index} className="p-3 bg-red-50 rounded-lg">
                                  <h5 className="font-medium text-red-800">{allergy.allergen}</h5>
                                  <p className="text-sm text-red-600">
                                    Severity: {allergy.severity}
                                  </p>
                                  {allergy.symptoms && (
                                    <p className="text-sm text-red-500 mt-1">
                                      Symptoms: {allergy.symptoms}
                                    </p>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {(!patientMedicalHistory.conditions || patientMedicalHistory.conditions.length === 0) &&
                         (!patientMedicalHistory.medications || patientMedicalHistory.medications.length === 0) &&
                         (!patientMedicalHistory.allergies || patientMedicalHistory.allergies.length === 0) && (
                          <div className="text-center py-8">
                            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-500">No medical history recorded</p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">Loading medical history...</p>
                      </div>
                    )}
                  </TabsContent>

                  {/* Lifestyle Tab */}
                  <TabsContent value="lifestyle" className="space-y-6">
                    {patientMedicalHistory?.lifestylePlans ? (
                      <div className="space-y-6">
                        {/* Diet Plan Section */}
                        {patientMedicalHistory.lifestylePlans.dietPlan && (
                          <Card>
                            <CardHeader>
                              <CardTitle className="flex items-center">
                                <Apple className="h-5 w-5 mr-2 text-red-500" />
                                Diet & Nutrition Plan
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {/* Diet Goals */}
                              {patientMedicalHistory.lifestylePlans.dietPlan.goals && (
                                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                                  <h5 className="font-semibold text-green-800 mb-2 flex items-center">
                                    <Target className="h-4 w-4 mr-2" />
                                    Diet Goals
                                  </h5>
                                  <p className="text-sm text-green-700">{patientMedicalHistory.lifestylePlans.dietPlan.goals}</p>
                                </div>
                              )}

                              {/* Water Intake */}
                              {patientMedicalHistory.lifestylePlans.dietPlan.waterIntake > 0 && (
                                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                  <h5 className="font-semibold text-blue-800 mb-2 flex items-center">
                                    <Droplet className="h-4 w-4 mr-2" />
                                    Daily Water Intake
                                  </h5>
                                  <p className="text-sm text-blue-700">
                                    {patientMedicalHistory.lifestylePlans.dietPlan.waterIntake} glasses per day
                                  </p>
                                </div>
                              )}

                              {/* Meals */}
                              {patientMedicalHistory.lifestylePlans.dietPlan.meals && 
                               patientMedicalHistory.lifestylePlans.dietPlan.meals.length > 0 && (
                                <div>
                                  <h5 className="font-semibold mb-3">Planned Meals ({patientMedicalHistory.lifestylePlans.dietPlan.meals.length})</h5>
                                  <div className="space-y-2">
                                    {patientMedicalHistory.lifestylePlans.dietPlan.meals.map((meal, index) => (
                                      <div key={meal?.id || index} className="p-3 border rounded-lg">
                                        <div className="flex items-center justify-between">
                                          <div>
                                            <h6 className="font-medium">{meal?.name}</h6>
                                            <div className="text-sm text-gray-600 mt-1">
                                              {meal?.time && <span>Time: {meal.time} | </span>}
                                              {meal?.calories && <span>Calories: {meal.calories} kcal</span>}
                                            </div>
                                            {meal?.notes && (
                                              <p className="text-xs text-gray-500 mt-1">{meal.notes}</p>
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Dietary Restrictions */}
                              {patientMedicalHistory.lifestylePlans.dietPlan.restrictions && 
                               patientMedicalHistory.lifestylePlans.dietPlan.restrictions.length > 0 && (
                                <div>
                                  <h5 className="font-semibold mb-3">Dietary Restrictions ({patientMedicalHistory.lifestylePlans.dietPlan.restrictions.length})</h5>
                                  <div className="space-y-2">
                                    {patientMedicalHistory.lifestylePlans.dietPlan.restrictions.map((restriction, index) => (
                                      <div key={restriction?.id || index} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                                        <h6 className="font-medium text-yellow-800 capitalize">{restriction?.type}</h6>
                                        {restriction?.description && (
                                          <p className="text-sm text-yellow-700 mt-1">{restriction.description}</p>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Supplements */}
                              {patientMedicalHistory.lifestylePlans.dietPlan.supplements && 
                               patientMedicalHistory.lifestylePlans.dietPlan.supplements.length > 0 && (
                                <div>
                                  <h5 className="font-semibold mb-3">Supplements & Vitamins ({patientMedicalHistory.lifestylePlans.dietPlan.supplements.length})</h5>
                                  <div className="space-y-2">
                                    {patientMedicalHistory.lifestylePlans.dietPlan.supplements.map((supplement, index) => (
                                      <div key={supplement?.id || index} className="p-3 border rounded-lg">
                                        <h6 className="font-medium">{supplement?.name}</h6>
                                        <div className="text-sm text-gray-600 mt-1">
                                          {supplement?.dosage && <span>Dosage: {supplement.dosage} | </span>}
                                          {supplement?.frequency && <span>Frequency: {supplement.frequency}</span>}
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        )}

                        {/* Exercise Plan Section */}
                        {patientMedicalHistory.lifestylePlans.exercisePlan && (
                          <Card>
                            <CardHeader>
                              <CardTitle className="flex items-center">
                                <Activity className="h-5 w-5 mr-2 text-green-500" />
                                Exercise & Fitness Plan
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {/* Exercise Goals */}
                              {patientMedicalHistory.lifestylePlans.exercisePlan.goals && (
                                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                  <h5 className="font-semibold text-blue-800 mb-2 flex items-center">
                                    <Target className="h-4 w-4 mr-2" />
                                    Fitness Goals
                                  </h5>
                                  <p className="text-sm text-blue-700">{patientMedicalHistory.lifestylePlans.exercisePlan.goals}</p>
                                </div>
                              )}

                              {/* Weekly Target */}
                              {patientMedicalHistory.lifestylePlans.exercisePlan.weeklyTarget > 0 && (
                                <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                                  <h5 className="font-semibold text-purple-800 mb-2 flex items-center">
                                    <Clock className="h-4 w-4 mr-2" />
                                    Weekly Exercise Target
                                  </h5>
                                  <p className="text-sm text-purple-700">
                                    {patientMedicalHistory.lifestylePlans.exercisePlan.weeklyTarget} hours per week
                                  </p>
                                </div>
                              )}

                              {/* Exercise Activities */}
                              {patientMedicalHistory.lifestylePlans.exercisePlan.activities && 
                               patientMedicalHistory.lifestylePlans.exercisePlan.activities.length > 0 && (
                                <div>
                                  <h5 className="font-semibold mb-3">Exercise Activities ({patientMedicalHistory.lifestylePlans.exercisePlan.activities.length})</h5>
                                  <div className="space-y-2">
                                    {patientMedicalHistory.lifestylePlans.exercisePlan.activities.map((activity, index) => (
                                      <div key={activity?.id || index} className="p-3 border rounded-lg">
                                        <h6 className="font-medium">{activity?.name}</h6>
                                        <div className="text-sm text-gray-600 mt-1 flex flex-wrap gap-3">
                                          {activity?.duration && <span>Duration: {activity.duration} min</span>}
                                          {activity?.intensity && (
                                            <span className="capitalize">Intensity: {activity.intensity}</span>
                                          )}
                                          {activity?.calories && <span>Calories: {activity.calories} kcal</span>}
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        )}

                        {/* Health Metrics Section */}
                        {patientMedicalHistory.lifestylePlans.healthMetrics && (
                          <Card>
                            <CardHeader>
                              <CardTitle className="flex items-center">
                                <TrendingUp className="h-5 w-5 mr-2 text-blue-500" />
                                Health Metrics Tracking
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {['weight', 'bloodPressure', 'heartRate', 'sleepHours', 'bloodSugar', 'temperature'].map((metricType) => {
                                  const metrics = patientMedicalHistory.lifestylePlans.healthMetrics[metricType] || [];
                                  if (metrics.length === 0) return null;

                                  const displayName = metricType
                                    .replace(/([A-Z])/g, ' $1')
                                    .replace(/^./, str => str.toUpperCase());
                                  
                                  const latestMetric = metrics[metrics.length - 1];
                                  const sortedMetrics = [...metrics].sort((a, b) => 
                                    new Date(b.date || 0) - new Date(a.date || 0)
                                  );

                                  return (
                                    <div key={metricType} className="border rounded-lg p-4">
                                      <div className="flex items-center justify-between mb-3">
                                        <h5 className="font-semibold flex items-center">
                                          {metricType === 'weight' && <Target className="h-4 w-4 mr-2" />}
                                          {metricType === 'bloodPressure' && <Heart className="h-4 w-4 mr-2" />}
                                          {metricType === 'heartRate' && <Activity className="h-4 w-4 mr-2" />}
                                          {metricType === 'sleepHours' && <Clock className="h-4 w-4 mr-2" />}
                                          {metricType === 'bloodSugar' && <TrendingUp className="h-4 w-4 mr-2" />}
                                          {metricType === 'temperature' && <Flame className="h-4 w-4 mr-2" />}
                                          {displayName}
                                        </h5>
                                        <span className="text-xs text-gray-500">{metrics.length} records</span>
                                      </div>
                                      
                                      {latestMetric && (
                                        <div className="mb-3">
                                          <p className="text-2xl font-bold">{latestMetric.value}</p>
                                          {latestMetric.date && (
                                            <p className="text-xs text-gray-500 mt-1">
                                              Latest: {new Date(latestMetric.date).toLocaleDateString()}
                                            </p>
                                          )}
                                        </div>
                                      )}

                                      <div className="space-y-1 max-h-40 overflow-y-auto">
                                        {sortedMetrics.slice(0, 5).map((metric, idx) => (
                                          <div key={metric?.id || idx} className="text-xs p-2 bg-gray-50 rounded">
                                            <div className="flex justify-between">
                                              <span className="font-medium">{metric.value}</span>
                                              {metric.date && (
                                                <span className="text-gray-500">
                                                  {new Date(metric.date).toLocaleDateString('en-US', { 
                                                    month: 'short', 
                                                    day: 'numeric'
                                                  })}
                                                </span>
                                              )}
                                            </div>
                                            {metric.notes && (
                                              <p className="text-gray-600 mt-1">{metric.notes}</p>
                                            )}
                                          </div>
                                        ))}
                                        {sortedMetrics.length > 5 && (
                                          <p className="text-xs text-gray-500 text-center pt-2">
                                            +{sortedMetrics.length - 5} more records
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                              
                              {(() => {
                                const hasAnyMetrics = ['weight', 'bloodPressure', 'heartRate', 'sleepHours', 'bloodSugar', 'temperature']
                                  .some(type => (patientMedicalHistory.lifestylePlans.healthMetrics[type] || []).length > 0);
                                
                                if (!hasAnyMetrics) {
                                  return (
                                    <div className="text-center py-8 text-gray-500">
                                      <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                                      <p>No health metrics recorded yet</p>
                                    </div>
                                  );
                                }
                                return null;
                              })()}
                            </CardContent>
                          </Card>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Activity className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-500">No lifestyle information available</p>
                        <p className="text-sm text-gray-400 mt-2">Patient hasn't set up their lifestyle plans yet</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Patient</h3>
                <p className="text-gray-500">Choose a patient from the list to view their medical records</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatientRecords;
